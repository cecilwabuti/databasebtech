package com.example.pavneet_singh.roomdemo.adapter;

import android.content.Context;

import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pavneet_singh.roomdemo.R;
import com.example.pavneet_singh.roomdemo.notedb.model.Note;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;



public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.BeanHolder> {

    private List<Note> list;
    List<Note> filteredlist;
//    private Context context;
    private LayoutInflater layoutInflater;
    private OnNoteItemClick onNoteItemClick;

    public NotesAdapter(List<Note> list, Context context) {
        layoutInflater = LayoutInflater.from(context);
        this.list = list;
        this.filteredlist = list;
        this.onNoteItemClick = (OnNoteItemClick) context;
    }


    @NonNull
    @Override
    public BeanHolder onCreateViewHolder(@NonNull ViewGroup parent,int viewType) {
        View view = layoutInflater.inflate(R.layout.note_list_item, parent, false);
        return new BeanHolder(view);
    }

    @Override
    public void onBindViewHolder(BeanHolder holder, int position) {
        Log.e("bind", "onBindViewHolder: " + list.get(position));
        holder.textViewTitle.setText(list.get(position).getTitle());
        holder.textViewContent.setText(list.get(position).getContent());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public Note getItem(int position) {
        return list.get(position);}

    @Override
    public long getItemId(int position) {
        return position;
    }

    public class BeanHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView textViewContent;
        TextView textViewTitle;
        TextView textViewPhone;

        public BeanHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            textViewContent = itemView.findViewById(R.id.item_text);
            textViewTitle = itemView.findViewById(R.id.tv_title);
            textViewPhone= itemView.findViewById(R.id.et_title2);
        }

        @Override
        public void onClick(View view) {
            onNoteItemClick.onNoteClick(getAdapterPosition());
        }
    }

    public interface OnNoteItemClick {
        void onNoteClick(int pos);
    }
    public Filter getFilter() {
        return new Filter() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults filterResults = new FilterResults();
                if (constraint != null && constraint.length() > 0) {
                    filterResults.count = list.size();
                    filterResults.values = list;


                } else {
                    List<Note> resultsModel = new ArrayList<>();
                    String searchStr = Objects.requireNonNull(constraint).toString().toLowerCase();

                    for (Note item : list) {
                        if (item.getTitle().toLowerCase().contains(searchStr) || item.getContent().contains(searchStr) || item.getPhone().contains(searchStr)) {
                            resultsModel.add(item);

                        }
                        filterResults.count = resultsModel.size();
                        filterResults.values = resultsModel;
                    }
                }
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence constraint,FilterResults results) {
                filteredlist = (List<Note>) results.values;
                notifyDataSetChanged();
            }


        };
    }}
